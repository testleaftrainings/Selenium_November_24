package com.leaftaps.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods{
	
	@Then("Verify the Title")
	public HomePage verifyPage() {
		verifyTitle("Home | Salesforce");
		return this;
		
	}
	
	
}
