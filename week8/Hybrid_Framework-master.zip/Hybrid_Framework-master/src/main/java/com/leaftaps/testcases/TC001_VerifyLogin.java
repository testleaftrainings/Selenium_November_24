package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;

public class TC001_VerifyLogin extends ProjectSpecificMethods{
	
@BeforeTest
	public void setValue() {
	excelFileName="Login";
	testcaseName="Salesforce";
	testDescription="Login page";
	authors="Dilip";
	category="Sanity";
	}

@Test(dataProvider = "fetchData")
public void runLogin(String un,String pw) {
	LoginPage lp=new LoginPage();
	lp.enterUserName(un)
	.password(pw)
	.clickLoginButton()
	.verifyPage();
}

}
