package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods{
	
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterUserName(String uname) {
		
//		WebElement un = locateElement("username");
//		clearAndType(un, uname);
		
		clearAndType(locateElement("username"), uname);
		reportStep("Enter the userName Successful"+uname,"pass",true);
		
		// type(null, uname);
		return this;
		
	}
	
	@And ("Enter the password as {string}")
	public LoginPage password(String pass) {
		
		type(locateElement(Locators.NAME, "pw"), pass);
		reportStep("Enter the Password Successful"+pass,"pass",true);
		
		return this;
	}
	
	@When("Click on login button")
	public HomePage clickLoginButton() {
		click(locateElement(Locators.XPATH, "//input[@id='Login']"));
		reportStep("Login is Successful","pass");
		
		return new HomePage();
	}
	
}
