package week8.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandelSeleniumException {

	public static void main(String[] args) {

		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		try {
			driver.findElement(By.id("usernam")).sendKeys("DemoSalesManager");
		} catch (Exception e) {
			System.out.println(e);
			driver.findElement(By.name("USERNAME")).sendKeys("Democsr");
		}
		
		
		try {
			driver.findElement(By.id("password")).sendKeys("crmsfa");
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
