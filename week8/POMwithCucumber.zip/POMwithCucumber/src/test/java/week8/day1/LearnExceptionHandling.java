package week8.day1;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		int[] num= {34,56,32,45,12,45,79};
		
		//0-6
		try {
			System.out.println(num[2]);
		} catch (Exception e) {
			System.out.println(e);
			System.out.println(num[6]);
		}
		
		System.out.println(num[4]);
		
		
		
		try {
			System.out.println(num[7]);
		} finally {
			System.out.println("data found");
		}
		
		
	}

}
