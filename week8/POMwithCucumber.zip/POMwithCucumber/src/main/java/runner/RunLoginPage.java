
package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunLoginPage extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
		testName="LoginPageTestNG";
		testDescription="Executing from TestNG";
		testAuthor="Dilip";
		testCategory="Sanity";
	}

	
	
	@Test()
	public void runloginData() throws IOException {
		
		System.out.println();
		LoginPage lp=new LoginPage();
		lp.enterUserName("DemoCsr")
		.enterPassWord("crmsfa")
		.clickOnLoginButton()
		.clickOnCrmsfa().clickOnLeads();
		
	}
	
}
