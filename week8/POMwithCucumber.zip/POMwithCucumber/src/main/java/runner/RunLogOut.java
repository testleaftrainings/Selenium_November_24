package runner;

import java.io.IOException;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunLogOut extends ProjectSpecificMethod{

	
	@Test
	public void runloginData() throws IOException {
		System.out.println();
		LoginPage lp=new LoginPage();
		lp.enterUserName("DemoCsr")
		.enterPassWord("crmsfa")
		.clickOnLoginButton()
		.clickOnLogOut();
		
	}
	
}
