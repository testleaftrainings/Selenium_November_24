package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(features="src/main/java/feature/Login2.feature", 
glue="pages",publish=true)

public class CucumberLoginPage  extends ProjectSpecificMethod{
	/*
	 * @DataProvider(parallel=true) public Object[][] scenarios() { return
	 * super.scenarios(); }
	 */
	  
	  @BeforeTest
	  public void setValue() {
		 testName="LoginPage";
		 testDescription="Executing from Cucumber";
		 testAuthor="Dilip";
		 testCategory="Sanity";
	  }

}
