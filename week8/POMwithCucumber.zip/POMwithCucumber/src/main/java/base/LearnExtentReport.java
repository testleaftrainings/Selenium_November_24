package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		//step 1
		ExtentHtmlReporter er=new ExtentHtmlReporter("./report/basicReport.html");
	//retain existing report
		er.setAppendExisting(true);
		
		//step2
		ExtentReports ers=new ExtentReports();
		
		//step 3
		ers.attachReporter(er);
		
		//step 4
		
		ExtentTest test = ers.createTest("Login Sceanrio", "Login with multiple data");
		test.assignAuthor("Dilip");
		test.assignCategory("Sanity");
		
		//step 5
		test.pass("Enter the username as DemoCsr");
		test.pass("Enter the password as cemsfa");
		test.fail("Click on LoginButton");
		test.pass("click on crmsfa", MediaEntityBuilder.createScreenCaptureFromPath(".././snapShot/takeSnap.png").build());
		
		
		ExtentTest test1 = ers.createTest("Login Sceanrio", "Login with multiple data");
		test1.assignAuthor("Gokul");
		test1.assignCategory("Smoke");
		
		//step 5
		test1.pass("Enter the username as DemoCsr");
		test1.pass("Enter the password as cemsfa");
		test1.pass("Click on LoginButton");
		
		//step 6
		ers.flush();
		System.out.println("done");
		
		
	}

}
