package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.utils.FileUtil;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataLibrary;


public class ProjectSpecificMethod  extends AbstractTestNGCucumberTests{


	private static final ThreadLocal<RemoteWebDriver> tlDriver=new ThreadLocal<RemoteWebDriver>();

	public static Properties pro;

	public String data;

	public ExtentHtmlReporter er;
	public static ExtentReports ers;
//step 5
	public static ExtentTest test,node;
//step 6	
	public String testName,testDescription,testCategory,testAuthor;
	
	
	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}

	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}
	@BeforeMethod
	public void preCondition() throws IOException {

		FileInputStream fis=new FileInputStream("src/main/resources/LeafTaps.En.properties");

		pro=new Properties();
		pro.load(fis);
		//parallel execute  - give node as globally and static variable
  
		
		
		setDriver();
		node = test.createNode(testName);
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();	

	}

	@DataProvider(name="getData")
	public String[][] fetchData() throws IOException {
		return DataLibrary.readvalue(data);
	}


//step 1
	@BeforeSuite
	public void startReport() {
		 er=new ExtentHtmlReporter("./report/POM1Report.html");
			er.setAppendExisting(true);
//step 2			
			ers=new ExtentReports();
			ers.attachReporter(er);
	}
	
//step 3
	
	@AfterSuite
	public void stopReport() {
		ers.flush();
	}
	
//step 4
	
	@BeforeClass
	public void testDetails() {
		
	 test= ers.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	
//step9
	
	public void reportStep(String stepDetails,String status) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			node.pass(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snapShot/takeSnap"+takesnap()+".png").build());
		}else if(status.equalsIgnoreCase("fail")) {
			node.fail(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snapShot/takeSnap"+takesnap()+".png").build());
			
			
		}
		
	}
	
	
	public int takesnap() throws IOException {
		int random =(int)( Math.random()*99999);
		File scr = getDriver().getScreenshotAs(OutputType.FILE);
		File dest=new File("./snapShot/takeSnap"+random+".png");
		FileUtils.copyFile(scr, dest);
		//takeSnap1339
		//takeSnap9790
		//takeSnap4356809
		return random;
	}
	
	
	
	
	
	
}