package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadTheValueFromPropertiesFile {

	public static void main(String[] args) throws IOException {

		//step 1
		FileInputStream fis=new FileInputStream("src/main/resources/LeafTaps.Fr.properties");
	
	//step2
		Properties pro=new Properties();
		
		//
		pro.load(fis);
		
		//read the value
		String property = pro.getProperty("username");
		System.out.println(property);
		
		String property2 = pro.getProperty("myhomepage.leads");
		System.out.println(property2);
	
	
	}

}
