package base;

public class PrintrandomNumber {

	public static void main(String[] args) {

		int random =(int)( Math.random()*99999);
		System.out.println(random);
		
		//0.861210628633021
		//0.5186304727765992
		//81627



	}

}
