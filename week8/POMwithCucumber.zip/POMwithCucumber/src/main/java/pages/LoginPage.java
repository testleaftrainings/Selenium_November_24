package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {


	
	@When("Enter the username as {string}")
	public LoginPage enterUserName(String uname) throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uname);
			reportStep("UserName enter successful","Pass");
			
		} catch (NoSuchElementException e) {
			System.out.println(e);
			getDriver().findElement(By.name("USERNAME")).sendKeys("DemoCsr");
			reportStep("Username is not enter successful", "fail");
		}catch(Exception e) {
			System.out.println(e);
			reportStep("Username is not enter successful", "fail");
		}
		
		return this;
	}
	
	@And("Enter the password as {string}")
	public LoginPage enterPassWord(String pass) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pass);
			reportStep("Password enter successful", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Password is not enter successful", "fail");
		}
		return this;
	}
	
	
	@And("Click on LoginButton")
	public HomePage clickOnLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button clicked successful", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Login button is not clicked successful", "fail");
		}
		return new HomePage();
	}
	
	
	
}
