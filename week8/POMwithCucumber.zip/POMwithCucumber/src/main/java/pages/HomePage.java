package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod{


	
	@Then("Verify the title")
	public HomePage verifyTitle() {
		String title = getDriver().getTitle();
		if(title.contains("TestLeaf")) {
			System.out.println("Login is successful");
			test.info("Login is Successful");
		}else {
			System.out.println("Login is not successful");
			test.info("Login is not successful");
		}
		return this;
	}
	
	
	@When("Click on crmsfa")
	public MyHomePage clickOnCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("CRMSFA clicked successful", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("CRMSFA is not clicked successful", "fail");
		} 
		 return new MyHomePage();
	}
	
	public LoginPage clickOnLogOut() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("LogOut button clicked", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("LogOut is not Clicked", "fail");
		}
		return new LoginPage();
	}
	
	
}
