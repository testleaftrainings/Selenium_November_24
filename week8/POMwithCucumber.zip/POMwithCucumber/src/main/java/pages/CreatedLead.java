package pages;

public class CreatedLead {

}
