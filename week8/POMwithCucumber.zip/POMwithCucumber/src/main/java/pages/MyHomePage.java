package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {

	
	
	public void clickOnLeads() throws IOException {
		try {
			getDriver().findElement(By.linkText(pro.getProperty("myhomepage.leads"))).click();
reportStep("Leads button is clicked", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Leads button is not clicked", "fail");
		}
		
	}
	
	
	
	public void clickOnAccounts() {
		
	}
	
	
	public void clickOnCases() {
		
	}
}



