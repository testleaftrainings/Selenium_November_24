package com.salesforce.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods{
	
	@Then("Verify the Title")
	public HomePage verifypage() throws InterruptedException {
		Thread.sleep(4000);
		
		verifyTitle("Home | Salesforce");
		return this;
	}

}
