
package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunLoginPage extends ProjectSpecificMethod{

	@BeforeTest
	public void setValue() {
		data="Login";
	}
	
	
	@Test(dataProvider = "getData")
	public void runloginData(String uname,String password) {
		
		System.out.println(driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(uname)
		.enterPassWord(password)
		.clickOnLoginButton()
		.clickOnCrmsfa().clickOnLeads();
		
	}
	
}
